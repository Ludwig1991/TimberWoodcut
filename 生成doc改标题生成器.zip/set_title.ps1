$ErrorActionPreference = 'SilentlyContinue'
$shell = New-Object -ComObject Shell.Application
$desktop = $shell.NameSpace(0)
$path = 'D:\Desktop\8-省（市）级行政区划码表.docx'
$folder = $shell.NameSpace('D:\Desktop')
$item = $folder.ParseName('8-省（市）级行政区划码表.docx')
$item.ExtendedProperties('Title').Value = '二五江苏B - 严执法化优服务民生底色久弥新'
Write-Output 'Done via Shell'
