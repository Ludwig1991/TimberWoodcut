# 1. 输入原始数据和生成多项式（二进制）
data = input("请输入待传送数据（二进制）：")
poly = input("请输入生成多项式（二进制）：")

# 生成多项式的阶数 r
r = len(poly) - 1

# 2. 发送端：补 r 个 0，准备做模2除法
data1 = data + "0" * r

data_list = list(data1)
poly_list = list(poly)

# 3. 模2除法（核心：见1才异或）
for i in range(len(data)):
    if data_list[i] == "1":
        # 逐位异或
        for j in range(len(poly)):
            if data_list[i + j] == poly_list[j]:
                data_list[i + j] = "0"
            else:
                data_list[i + j] = "1"

# 4. 得到 CRC 校验码
crc = "".join(data_list[-r:])
send_code = data + crc

# ===================== 发送端结束 =====================

print("\n===== 发送端结果 =====")
print("原始数据：", data)
print("生成多项式：", poly)
print("CRC 校验码：", crc)
print("最终发送数据：", send_code)

# ===================== 接收端检验 =====================

print("\n===== 接收端检验 =====")
receive_code = input("请输入接收到的数据：")

# 对接收到的整个数据做一次模2除法
recv_list = list(receive_code)
poly_list = list(poly)

# 同样的模2除法
for i in range(len(receive_code) - r):
    if recv_list[i] == "1":
        for j in range(len(poly)):
            if recv_list[i + j] == poly_list[j]:
                recv_list[i + j] = "0"
            else:
                recv_list[i + j] = "1"

# 最后 r 位就是余数
remainder = "".join(recv_list[-r:])

print("计算余数：", remainder)

# 检验规则：余数全0 → 正确
if remainder == "0" * r:
    print("检验结果：数据正确，无差错 ✅")
else:
    print("检验结果：数据出错 ❌")

