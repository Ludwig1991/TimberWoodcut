$ErrorActionPreference = 'SilentlyContinue'
$word = New-Object -ComObject Word.Application
$word.Visible = 0
$word.DisplayAlerts = 0
$doc = $word.Documents.Add()
$selection = $word.Selection

$txt = Get-Content -Path 'D:\Desktop\content.txt' -Raw -Encoding UTF8
$selection.TypeText($txt)

$outPath = 'D:\Desktop\8-省（市）级行政区划码表.docx'
$doc.SaveAs([System.IO.Path]::GetFullPath($outPath), 16)
$doc.Close()
$word.Quit()
Write-Output "Done: $outPath"
