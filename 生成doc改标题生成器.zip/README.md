﻿
# 省（市）级行政区划码表生成器

> 适用平台：Windows（依赖 Word COM + Shell COM）

## 工作流说明

本工具包用于将纯文本内容生成为带元数据的 Word 文档，完整流程如下：

`
┌─────────────────────┐
│  content.txt       │  ← 素材文件（用户自行准备）
└──────────┬──────────┘
           │
    ┌──────▼──────┐
    │ create_doc  │  Word COM → 读取纯文本 → 生成标准 docx
    └──────┬──────┘
           │
    ┌──────▼──────┐
    │ set_title   │  Shell COM → 写入 Title 文件属性
    └──────┬──────┘
           │
    ┌──────▼──────┐
    │ 成品 docx   │  内容完整 + 元数据齐全
    └─────────────┘
`

## 文件清单

| 文件 | 大小 | 用途 |
|------|------|------|
| create_doc.ps1 | 467B | Word COM 创建文档，写入 content.txt 正文内容，输出 docx |
| set_title.ps1 | 430B | Shell COM 写入文件 Title 属性（Windows 资源管理器可见） |
| README.md |本文档 | 说明文档 |

## 环境依赖

- Windows 7/10/11
- Microsoft Word（已安装 COM 组件）
- PowerShell 5.1+

## 使用方法

### 前置准备

将待写入的文本内容保存为：
`
D:\Desktop\content.txt
`

### 第一步：生成文档

`powershell
powershell -ExecutionPolicy Bypass -File E:\省（市）级行政区划码表生成器\create_doc.ps1
`

输出文件：D:\Desktop\8-省（市）级行政区划码表.docx

### 第二步：写入元数据

`powershell
powershell -ExecutionPolicy Bypass -File E:\省（市）级行政区划码表生成器\set_title.ps1
`

效果：在资源管理器中该文件属性详情页可见「二五江苏B - 严执法化优服务民生底色久弥新」

## 脚本分工辩证

| 脚本 | 职责 | 技术手段 | 为何分离 |
|------|------|----------|----------|
| create_doc.ps1 | 正文写入 | Word.Application COM | 生成文档正文是 Word 的本职 |
| set_title.ps1 | 属性写入 | Shell.Application COM | Title 是文件系统属性，非文档内部属性 |

**分离的合理性**：
- Word COM 擅长处理文档内部内容，不擅长修改文件系统属性
- Shell COM 擅长操作文件元数据，但不负责文档内容生成
- 各司其职，互不侵入，调试时可单独运行验证

**可改进方向（可选）**：
- 合并为单脚本，一步完成
- 将 content.txt 路径、输出路径、标题做成参数化
- 增加错误重试机制（COM 组件有时需要初始化等待）

## 注意事项

- 两个脚本需按顺序执行，先 create 后 set_title
- 输出路径硬编码为 D:\Desktop\，如需修改请编辑脚本内变量
- set_title.ps1 使用 Shell COM，修改的是「文件属性」而非「文档内部属性」
- 部分杀毒软件可能拦截 COM 组件操作，请添加白名单

## 版本信息

- 创建日期：2026-04-13
- 适用场景：批量生成规范化 docx 文件并统一元数据
- 作者：苏林整理

