data = input("请输入待传送数据：")
poly = input("请输入生成多项式对应的二进制数：")
#生成多项式的阶为r
r = len(poly) - 1
#在帧的低位端加上r个0
data1 = data + "0" * r

data_list = list(data1)
poly_list = list(poly)
#模2除（异或运算）。
for i in range(len(data)):
    #只有当前位是1才能做异或
    if data_list[i] == "1":
        #逐位异或 相同为0 相异为1
        for j in range(len(poly)):
            #data_list[i + j]为从第i位开始，向后偏移j位的那一位数据
            if data_list[i + j] == poly_list[j]:
                data_list[i + j] = "0"
            else:
                data_list[i + j] = "1"
#余数位数=多项式位数—1 取最后几位当余数 余数为CRC校验码
crc = "".join(data_list[-r:])
send_code = data + crc
print("输入数据：",data)
print("生成多项式",poly)
print("CRC校验码",crc)
print("发送数据",send_code)


